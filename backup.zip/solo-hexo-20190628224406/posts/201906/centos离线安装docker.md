title: centos离线安装docker
date: '2019-06-16 22:24:04'
updated: '2019-06-16 22:25:16'
tags: [docker]
permalink: /mydocker
---
![](https://img.hacpai.com/bing/20190310.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## centos离线安装docker
### 基本思路
1. 在可以连接外网的机器（未安装过docker，同时跟局域网要安装docker的机器系统版本一致）通过yum命令将rpm以及相关的依赖下载完成
2. 将下载完成的rpm包，拷贝到局域网机器上面
3. 构建本地yum源
4. 使用yum install docker安装，安装完成

### docker离线安装包的下载
要下载docker离线安装包，需要通过yum的离线下载命令进行，一般我们使用yum install下载安装包会进行安装，安装完成后删除下载的安装包，yum提供了一种只下载安装包，但是不进行安装的方法：

```
yum install docker  --downloadonly --downloaddir=/home/docker_rpm -y
```
通过这个命令，我们可以将docker相关的rpm包下载到/home/docker/dockerRpm目录，如图： 

![image.png](https://img.hacpai.com/file/2019/06/image-f02a2fb2.png)

copy rpm包到需要安装docker的机器上面copy rpm包到需要安装docker的机器上面copy rpm包到需要安装docker的机器上面，例如：

```
/home/yum-custom/packages
```

构建本地yum源

注：如包依赖错误，可执行
```
rpm -ivh  *.rpm --nodeps --force 进行强制安装
```

1、构建本地源之前，需要在本地安装createrepo，用于构建本地源，方法，同docker包下载，通过yum install –downloadonly下载好，copy到该机器上面，通过rpm -ivh进行安装，createrepo关联包很少，不详细描述。

2、删除/etc/yum.repo.d目录下文件，创建新的*.repo文件，如：docker.repo，进行配置，如图：
![image.png](https://img.hacpai.com/file/2019/06/image-069a134e.png)

3、设置本地源，执行成功后本地源就设置完成了
createrepo -d /home/yum-custom/
输入yum repolist看是否能看到自己构建的本地源
4、清除缓存，yum clean all
5、创建缓存，yum makecache
**看本地源是否配置成功，通过yum list看是否输出了新的rpm包，如果能查询到，证明配置成功**