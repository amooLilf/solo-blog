title: 创建启动java项目镜像日记
date: '2019-06-16 14:25:18'
updated: '2019-06-16 14:25:42'
tags: [dockerfile]
permalink: /dockerfile
---
![](https://img.hacpai.com/bing/20190110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

1、准备好基础镜像（如果基础镜像没有安装jdk并且配置java环境，则在第三步中完成jdk的安装配置）	

2、编写好启动脚本  

3、构建dockerfile

4、根据dockerfile构建镜像

5、根据构建好的镜像，启动dock容器

6、校验容器

校验容器时候，可以先确保，容器能成功启动，并进入容器校验脚本。

然后确保脚本可以运行java项目时候，再重新修改宿主机的脚本，并且重新构建镜像。

最后把容器停止移除重新启动。

  

删除构建失败的镜像 
docker rmi $(docker images | awk '/^<none>/ { print $3 }')

  

校验过程中所重复用到的命令可以写在脚本 节省校验时间

shell

&和&&的区别  &是同时执行多个命令  &&是按顺序执行，当前一个执行失败后面命令便不会继续执行

  

不要把执行命令放在脚本变量里面 然后执行

如：

```
result = "java -Xms512m -Xmx512m  -jar /opt/apps/$module_name.jar >> /opt/project/logs/$module_name.out 2>&1 &"
nohup $result
```

