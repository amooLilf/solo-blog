title: Nginx 服务器证书安装(转发http请求到https)
date: '2019-09-30 15:35:01'
updated: '2019-09-30 15:49:04'
tags: [nginx, docke, https]
permalink: /articles/2019/09/30/1569828901336.html
---
![](https://img.hacpai.com/bing/20190304.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 原由
鉴于小程序发布需要用到网监局备案的域名（并且要基于https方式发送请求）
## 安装条件
基于以下几点进行安装部署
1. 腾讯云服务器
2. 备案域名
3. SSL证书
### 申请SSL证书
我申请的是免费证书（有效期一年）
[腾讯云Nginx安装SSL](https://cloud.tencent.com/document/product/400/6814)
![image.png](https://img.hacpai.com/file/2019/09/image-cb496532.png)
### 配置Nginx
1. docker pull nginx:1.16.0
官网使用的nginx的版本为1.16.0（不同的nginx版本开启ssl的配置的写法也不一样）
2. 修改nginx配置文件
```
user  nginx;

worker_processes  1;

error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile        on;
    #tcp_nopush     on;

    keepalive_timeout  65;

    #gzip  on;

    include /etc/nginx/conf.d/*.conf;

    server {
        #SSL 访问端口号为 443
        listen 443; 
        #填写绑定证书的域名
        server_name www.xxx.cn; 
        #启用 SSL 功能
        ssl on;
        #证书文件名称
        ssl_certificate 1_www.xxx.cn_bundle.crt; 
        #私钥文件名称
        ssl_certificate_key 2_www.xxx.cn.key; 
        ssl_session_timeout 5m;
        #请按照这个协议配置
        ssl_protocols TLSv1 TLSv1.1 TLSv1.2; 
        #请按照这个套件配置，配置加密套件，写法遵循 openssl 标准。
        ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE; 
        ssl_prefer_server_ciphers on;
        location / {
	  #网站请求地址 此处我写的是默认转发80端口到服务器的9090
           proxy_pass http://www.xxx.cn:9090; 
           add_header Access-Control-Allow-Origin *;
        }
    }
}
```
### docker容器启动命令
1. 将自定义的配置文件nginx.conf进行挂载覆盖
2. 将申请证书拿到的两个文件挂载到nginx的配置目录文件夹中
1_www.xxx.cn_bundle.crt
2_www.xxx.cn.key
3. 并且对外暴露80端口和443端口

```
docker run --name nginx --privileged=true -p 443:443 -p 80:80 \
 -v ~/nginx/log:/var/log/nginx \
 -v ~/nginx/conf/1_www.amoolee.cn_bundle.crt:/etc/nginx/1_www.xxx.cn_bundle.crt  \
 -v ~/nginx/conf/2_www.amoolee.cn.key:/etc/nginx/2_www.xxx.cn.key  \
 -v ~/nginx/conf/nginx.conf:/etc/nginx/nginx.conf  \
 -d nginx:1.16.0
```
