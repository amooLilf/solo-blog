title: vue项目集成cas登陆！
date: '2019-06-17 22:29:06'
updated: '2019-06-17 22:29:06'
tags: [CAS]
permalink: /cas
---
![](https://img.hacpai.com/bing/20180702.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

主流前后端分离项目，集成CAS系统进行改造。
前端的入口文件main.js进行改造，在入口文件项目初始化路由挂载的时候，发起同步请求，拿到dns_env.json(此文件后期运维人员可以在线修改，无需重新构建)如下图main.js文件

![null](https://uploader.shimo.im/f/LVdFYCC9l5YqSzM9!thumbnail)

dns_env.json文件

![null](https://uploader.shimo.im/f/9ZkLrVYU6WkpUD8t!thumbnail)

路由跳转先逻辑判断说明：

![null](https://uploader.shimo.im/f/ZwsLbyBYpDoJB65d!thumbnail)

同步请求本地json文件的请求代理设置index.js

![null](https://uploader.shimo.im/f/v26n6gTYcjcf8ZOy!thumbnail)